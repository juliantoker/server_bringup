drop table if exists account;
drop table if exists accountban;
drop table if exists characters;
drop table if exists rpobject;
drop table if exists rpslot;

drop table if exists loginEvent;
drop table if exists loginseed;
drop table if exists passwordChange;
drop table if exists rpzone;
drop table if exists statistics;
drop table if exists gameEvents;

drop table if exists banlist;


