Website template
----------------
This is a template to run a website for a arianne game server.
The idea behind this template is to allow you, the server hoster, to create your own 
website so that you allow users to create an account, view if server is up or not and
to follow a basic server statistics like server usage or top players.

To custometize this template you need to:
- Edit index.php configuration and fill it with correct values.
- Edit account.php configuration and fill it with correct values.

It should work as it is once you edit that two files.

Requirements:
-------------
- PHP 4.x
- MySQL
- Marauroa 0.41 or newer

Author
------
Miguel Angel Blanch Lardin <miguelangelblanchlardin at hotmail dot com>

License
-------
GPL